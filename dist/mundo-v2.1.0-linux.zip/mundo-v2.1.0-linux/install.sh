#!/bin/bash
set -e
echo "🖥️  MUNDO Agent v2.1.0 Linux 安装"
INSTALL_DIR="$HOME/.蒙多"
mkdir -p "$INSTALL_DIR"
cp -r . "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR"/scripts/*.sh 2>/dev/null
grep -q 'alias mundo=' ~/.bashrc 2>/dev/null || echo 'alias mundo="cd ~/.蒙多 && python3 start_agent.py"' >> ~/.bashrc
echo "✅ 安装完成！重启终端后运行: mundo"
