@echo off
echo MUNDO Agent v2.1.0 Windows 安装
set INSTALL_DIR=%USERPROFILE%\.蒙多
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
xcopy /E /I /Y . "%INSTALL_DIR%"
echo ✅ 安装完成！运行: %INSTALL_DIR%\mundo.bat
pause
